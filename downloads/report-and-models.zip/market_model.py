"""中国吻合器及垫片：条件情景模型。所有未注明外部来源的输入均为研究假设，非全国实测。"""
import csv, json
from pathlib import Path

OUT = Path(__file__).resolve().parent
# eligible_operations不是全部科室手术；各行手术互斥。价格统一为生产企业销售、未税假设。
SEGMENTS = [
 dict(segment='胸外科腔镜',eligible_operations=1500000,penetration=.90,body_units=1,body_price=350,cartridge_units=3.5,cartridge_price=400,integrated_units=0,integrated_price=0),
 dict(segment='胃肠腔镜（不含减重）',eligible_operations=2500000,penetration=.90,body_units=1,body_price=350,cartridge_units=3,cartridge_price=400,integrated_units=0,integrated_price=0),
 dict(segment='减重代谢',eligible_operations=50000,penetration=.95,body_units=1,body_price=350,cartridge_units=5,cartridge_price=400,integrated_units=0,integrated_price=0),
 dict(segment='其他腔镜（不与上述重复）',eligible_operations=1200000,penetration=.80,body_units=1,body_price=350,cartridge_units=2.5,cartridge_price=400,integrated_units=0,integrated_price=0),
 dict(segment='开放/管型等独立手术包',eligible_operations=1500000,penetration=.80,body_units=0,body_price=0,cartridge_units=0,cartridge_price=0,integrated_units=1,integrated_price=800),
]
PADS = [
 dict(segment='胸外科',eligible_operations=1500000,penetration=.03,sets_per_operation=1.2,price_per_set=2500),
 dict(segment='胃肠（不含减重）',eligible_operations=2500000,penetration=.005,sets_per_operation=1,price_per_set=2500),
 dict(segment='减重代谢',eligible_operations=50000,penetration=.15,sets_per_operation=2,price_per_set=2500),
]
SCENARIOS = {
 '保守':dict(procedure_growth=.03,core_price_growth=-.08,core_mix_growth=0,pad_penetration_growth=.10,pad_price_growth=-.10),
 '基准':dict(procedure_growth=.06,core_price_growth=-.04,core_mix_growth=.02,pad_penetration_growth=.20,pad_price_growth=-.06),
 '乐观':dict(procedure_growth=.09,core_price_growth=-.01,core_mix_growth=.03,pad_penetration_growth=.30,pad_price_growth=-.03),
}
def write_csv(name, rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 core=[]
 for x in SEGMENTS:
  n=x['eligible_operations']*x['penetration']
  amounts={k:n*x[k+'_units']*x[k+'_price'] for k in ['body','cartridge','integrated']}
  core.append(dict(**x,used_operations=n,**{k+'_revenue_yuan':v for k,v in amounts.items()},total_revenue_yuan=sum(amounts.values()),input_status='研究假设；非全国实测'))
 pads=[dict(**x,sets=x['eligible_operations']*x['penetration']*x['sets_per_operation'],revenue_yuan=x['eligible_operations']*x['penetration']*x['sets_per_operation']*x['price_per_set'],input_status='研究假设；非全国实测') for x in PADS]
 c=sum(x['total_revenue_yuan'] for x in core);p=sum(x['revenue_yuan'] for x in pads)
 forecasts=[]
 for name,s in SCENARIOS.items():
  for year in range(2025,2032):
   n=year-2025
   cv=c*((1+s['procedure_growth'])*(1+s['core_price_growth'])*(1+s['core_mix_growth']))**n
   pv=sum(x['eligible_operations']*(1+s['procedure_growth'])**n*min(1,x['penetration']*(1+s['pad_penetration_growth'])**n)*x['sets_per_operation']*x['price_per_set']*(1+s['pad_price_growth'])**n for x in PADS)
   forecasts.append(dict(scenario=name,year=year,core_yi=cv/1e8,pad_yi=pv/1e8,combined_yi=(cv+pv)/1e8,status='条件情景，非行业事实或统计置信区间'))
 sensitivity=[]
 for name,m in [('适用手术量',1.1),('本体及钉仓价格',1.1),('钉仓耗用量',1.1),('垫片使用渗透率',1.1)]:
  cv=c;pv=p
  if name=='适用手术量':cv*=m;pv*=m
  elif name=='本体及钉仓价格':cv*=m
  elif name=='钉仓耗用量':cv+=sum(x['cartridge_revenue_yuan'] for x in core)*(m-1)
  else:pv*=m
  sensitivity.append(dict(variable=name,change='+10%',core_yi=cv/1e8,pad_yi=pv/1e8,core_change_pct=(cv/c-1)*100,pad_change_pct=(pv/p-1)*100))
 write_csv('吻合器模型输入与测算.csv',core);write_csv('垫片模型输入与测算.csv',pads);write_csv('2026-2031条件情景.csv',forecasts);write_csv('敏感性分析.csv',sensitivity)
 (OUT/'模型假设.json').write_text(json.dumps(dict(segments=SEGMENTS,pads=PADS,scenarios=SCENARIOS,base_year=2025,price_basis='生产企业销售、未税；所有输入为待验证假设',exclusions='不含出口、疝补片、皮肤及包皮吻合器；垫片仅计算独立销售，集成价值包含在核心产品中'),ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(dict(core_yi=c/1e8,pad_yi=p/1e8,combined_yi=(c+p)/1e8,forecast=[x for x in forecasts if x['year'] in [2026,2029,2031]],core_components={k:sum(x[k+'_revenue_yuan'] for x in core)/1e8 for k in ['body','cartridge','integrated']},sensitivity=sensitivity),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
